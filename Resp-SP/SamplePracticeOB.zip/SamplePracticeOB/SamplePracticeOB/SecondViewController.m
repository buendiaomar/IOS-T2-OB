//
//  SecondViewController.m
//  SamplePracticeOB
//
//  Created by Consultant on 3/17/22.
//

#import "SecondViewController.h"
#import "ViewController.h"

NSString *selectedCountry = @"nationState";



@interface SecondViewController ()

@property (weak, nonatomic) IBOutlet UITableView *countryListTableView;



@end

@implementation SecondViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
}

-(void)setupConfiguration {
    self.title = @"List of Countries";
}

-(NSArray *)countriesList {
    
    NSArray *countriesList = [NSArray
                            arrayWithObjects:@"Costa Rica",@"Peru",@"Ireland",@"Finland", @"Germany",@"Australia",@"Chile", @"Thailand",@"Nepal",@"Laos", @"Netherlands",@"India", @"England",@"Italy",@"Japa",@"Austria",@"Switzerland",@"Marrocco",@"France",@"Mexico",nil ];
    return countriesList;
    
}
/*
 TableView Methods
 */

-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section {
    return  self.countriesList.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView
cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView
                             dequeueReusableCellWithIdentifier:selectedCountry forIndexPath:indexPath];
    
    cell.textLabel.text = [self.countriesList objectAtIndex:indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *) indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath  animated:false];
    [self.navigationController popToRootViewControllerAnimated:true];
    self.firstVC.clickHereLabel.text = [self.countriesList objectAtIndex:indexPath.row ];
    
    self.selectedCountry([self.countriesList objectAtIndex:indexPath.row]);
}

-(void)getLastCountry:(void (^)(NSString * _Nonnull))selectedCountry {
    self.selectedCountry(self.countriesList.lastObject);
}

@end
