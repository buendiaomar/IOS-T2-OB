//
//  ViewController.h
//  SamplePracticeOB
//
//  Created by Consultant on 3/17/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *clickHereView;
@property (weak, nonatomic) IBOutlet UILabel *clickHereLabel;


@end

